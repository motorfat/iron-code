<?php

/**
 * Fired during plugin activation
 *
 * @link       https://iron-code.ru
 * @since      1.0.0
 *
 * @package    Motordev
 * @subpackage Motordev/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Motordev
 * @subpackage Motordev/includes
 * @author     Eugene Motorfat <evgenyfeklistov@yandex.ru>
 */
class Motordev_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
